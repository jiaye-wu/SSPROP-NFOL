The example files in this directory illustrate how to use SSPROP
to simulate linear and nonlinear propagation in fiber.  The
examples reproduce many of the numerical results that are
presented in Govind. P. Agrawal's text, "Nonlinear Fiber Optics".

In addition to sspropc, these example routines use the utility
routines that are provided in the tools directory.  It is
recommended that you add this directory in addition to the main
ssprop directory to your Matlab path before running the
examples. 